public class Game
{
  private Grid grid;
  private int userRow;
  private int msElapsed;
  private int timesGet;
  private int timesAvoid;
  private int score;
  private boolean gameOver;
  private int lives = 4;
  
  public Game()
  {
    grid = new Grid(5, 10);
    userRow = 0;
    msElapsed = 0;
    timesGet = 0;
    timesAvoid = 0;
    updateTitle();
    grid.setImage(new Location(userRow, 0), "User.gif");
  }
  
  public void play()
  {
    while (!gameOver)
    {
      grid.pause(100);
      handleKeyPress();
      if (msElapsed % 300 == 0)
      {
        scrollLeft();
        populateRightEdge();
      }
      updateTitle();
      msElapsed += 100;
    }
  }
  
  public void handleKeyPress() {
      int key = grid.checkLastKeyPressed();
      if(key == 40){
          if(userRow < grid.getNumRows() - 1){
              grid.setImage(new Location(userRow,0), null);
              userRow += 1;
              handleCollision(new Location(userRow, 0));
              grid.setImage(new Location(userRow,0), "User.gif");  
          }
      }else if(key == 38){
          if(userRow > 0){
              grid.setImage(new Location(userRow,0), null);
              userRow -= 1;
              handleCollision(new Location(userRow, 0));
              grid.setImage(new Location(userRow,0), "User.gif");  
          }
      }
  }
  
  public void populateRightEdge(){
      
      for(int y = 0 ; y < grid.getNumRows() ; y++){
          double rand = Math.random();
          if(rand < 0.8){
              grid.setImage(new Location(y,grid.getNumCols() -1), null);
          }else if(rand < 0.9){
              grid.setImage(new Location(y,grid.getNumCols() -1), "Get.gif");
          }else if(rand < 1){
              grid.setImage(new Location(y,grid.getNumCols() -1), "Avoid.gif");
          }
      }
  }
  
  public void scrollLeft(){
      int rows = grid.getNumRows();
      int col = grid.getNumCols() -1;
      Location colLocation = new Location(userRow, 1);
      handleCollision(colLocation);
      for(int y = 0 ; y < rows ; y++){
          for(int x = 0 ; x < col ; x++){
              //Get current location
              Location currLocation = new Location(y,x);
              //Get location to the right
              Location rightLocation = new Location(y,x + 1);
              //Get the string of the right image
              String hold = (String)grid.getImage(rightLocation);
              grid.setImage(currLocation, hold);
          }
      }
      grid.setImage(new Location(userRow,0), "User.gif");
  }
  
  public void handleCollision(Location loc){
      String img = grid.getImage(loc);
      if(img != null){
          if(img.equals("Get.gif")){
              this.timesGet++;
              grid.setImage(loc, null);
              score += 2;
              isGameOver();
          }else if(img.equals("Avoid.gif")){
              this.timesAvoid++;
              grid.setImage(loc, null);
              score -= 1;
              lives--;
              isGameOver();
          }
      }
  }
  
  public int getScore(){
      return this.score;
  }
  
  public void updateTitle(){
    grid.setTitle("Lives: " +lives+ "\t Score: " +getScore());
    if(timesAvoid == 4){
        grid.setTitle("Game Over : Score was: " +this.score);
        grid.setImage(new Location(userRow,0), "Crash.gif");
    }else if(score >= 60){
        grid.setTitle("You won score is over 60 : Score was: " +this.score);
        grid.setImage(new Location(userRow,0), "Win.gif");
    }
  }
  
  public boolean isGameOver(){
      if(timesAvoid == 4){
          this.gameOver = true;
      }else if(score >= 60){
          this.gameOver = true;
      }
      return gameOver;
  }
  
  public static void test()
  {
    Game game = new Game();
    game.play();
  }
  
  public static void main(String[] args)
  {
    test();
  }
}